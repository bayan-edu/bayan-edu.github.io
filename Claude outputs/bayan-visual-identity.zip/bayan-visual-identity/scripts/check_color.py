#!/usr/bin/env python3
"""قِس لوناً مرشّحاً قبل اعتماده في بيان — الطريقة في §⑥ من SKILL.md.

الاستعمال:
    pip install coloraide            # أو: pip install --break-system-packages coloraide
    python check_color.py '#592F62'          # السِمة الفاتحة
    python check_color.py '#DB95CB' --dark   # السِمة الداكنة

يطبع ثلاثة أرقام، ولكلٍّ حدُّه:
  ① أسوأ ΔE2000 ضدّ كلّ عائلة في الرؤى الثلاث (عادية · عمى الأحمر · عمى الأخضر)
     — الحدّ العمليّ ≥ 8. ولا يُقاس اللون بنفسه: إن كان قيمةَ عائلةٍ قائمة استُثنيت.
  ② التباين مع الصفحة ومع السطح (البطاقة) — الحدّ ≥ 4.5 للنصّ، ويُؤخذ أدناهما.
  ③ إشباع OKLCH (C) — الهوية المكتومة بين 0.075 و0.103؛ accent وdanger وحدهما ≈ 0.20.

⚠️ الأرقام تمنع الخطأ ولا تُثبت الصواب: اعرض اللون في سياقه الحقيقي وفي السِمتين.
"""
import sys
from coloraide import Color

VIS = ["normal", "protan", "deutan"]
THEMES = {
    "light": {"page": "#F5F5F4", "surface": "#FFFFFF", "fam": {"accent": "#1D4ED8", "ok": "#0F6E56", "warn": "#663305",
                                          "danger": "#B91C1C", "dx": "#592F62", "text": "#292524"}},
    "dark": {"page": "#171717", "surface": "#262626", "fam": {"accent": "#93C5FD", "ok": "#34D399", "warn": "#FCD34D",
                                         "danger": "#F87171", "dx": "#DB95CB", "text": "#E5E5E5"}},
}


def see(c, v):
    return Color(c) if v == "normal" else Color(c).filter(v, 1).clip()


def report(hx, theme):
    t = THEMES[theme]
    others = {k: o for k, o in t["fam"].items() if o.upper() != hx.upper()}
    rows = sorted(((min(see(hx, v).delta_e(see(o, v), method="2000") for v in VIS), k)
                   for k, o in others.items()))
    l, c, h = Color(hx).convert("oklch").coords()
    con_p = Color(t["page"]).contrast(hx)
    con_s = Color(t["surface"]).contrast(hx)
    mark = lambda ok: "✅" if ok else "⚠️"
    print(f"\n{hx} · السِمة {theme} · صفحة {t['page']} · سطح {t['surface']}")
    print(f"  OKLCH  L {l:.3f} · C {c:.3f} · h {h:.1f}°")
    print("  ① أسوأ ΔE في الرؤى الثلاث ضدّ:")
    for d, k in rows:
        print(f"       {k:7} {d:5.1f}  {mark(d >= 8)}")
    print(f"  ② التباين: الصفحة {con_p:5.2f} · السطح {con_s:5.2f}  {mark(min(con_p, con_s) >= 4.5)} (للنصّ ≥ 4.5)")
    print(f"  ③ الإشباع C           {c:5.3f}  {mark(0.075 <= round(c, 3) <= 0.103)} (للهوية 0.075–0.103)")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        sys.exit(__doc__)
    for hx in args:
        report(hx, "dark" if "--dark" in sys.argv else "light")
